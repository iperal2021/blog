Dentro de la carpeta noUnibotics existen los siguientes archivos:

* Los archivos HAL, GUI y MAP
* Los ejemplos del docente
* El código entregado para la practica. Son tres archivos diferentes independientes uno de otros. Cada uno representa una versión:

1. montecarloVC_v1.py : version sin Pool ni comportamiento de aspiradora
2. montecarloVC_POOL.py : version con multiprocessing
3. montecarloVC_MOVEMENT.py : version con multiprocessing + movimiento de la p1

2 y 3 son los principales, hablo de ambas versiones en el blog.
